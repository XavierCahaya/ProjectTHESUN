<?php

return [
'description'=>'<h1 class="fade text-2xl mt-2 leading-snug" style="font-family: \'ZCOOL XiaoWei\', cursive;">
    The SUN Tour en Travel adalah Tour Planner, Tour Operator, Tour Agency yang berlokasi di SEMARANG, Jawa
    Tengah. Berdiri sejak 2012, kami mempunyai team ahli untuk mengakomodasikan semua kebutuhan Perjalanan,
    Wisata,
    Studi Banding, Golf dan MICE serta menyediakan kebutuhan transportasi dalam negeri dan luar negeri.
    Percayakan semua kebutuhan perjalanan anda hanya pada team yang profesional, The SUN Tour en Travel
    Semarang.
</h1>',
'cta_maps'=>'Lihat di Google Maps'


];