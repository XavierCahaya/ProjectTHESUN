<?php

return [

    'jelajahdunia' => 'Mulai Petualangan Anda Dengan Harga Spesial Yang Hanya Ada Di Sini.',
    'jelajahdunia2' => 'Promo eksklusif kami siap membawa Anda ke destinasi impian. 
                        Temukan penawaran terbaik per kota di Indonesia maupun luar negara, nikmati perjalanan tanpa batas, 
                        dan biarkan setiap promo membuka pintu petualangan baru untuk Anda.',

    'mengapakami' => 'MENGAPA HARUS KAMI ?',
    'pengalamansejak' => 'Bepengalaman Sejak 2012',
    'deskrip1' => 'Dengan lebih dari satu dekade pengalaman, kami memahami cara merancang perjalanan yang berkesan dan tanpa hambatan untuk Anda.',

    'timahli' => 'Tim Ahli & Profesional',
    'deskrip2' => 'Tim kami terdiri dari para ahli di bidang pariwisata yang siap mengakomodasi setiap detail kebutuhan perjalanan Anda dengan responsif dan solutif.',

    'layanan' => 'Layanan Terpadu Satu Pintu',
    'deskrip3' => 'Mulai dari tiket, akomodasi, transportasi, hingga paket wisata kustom, MICE, dan studi tur, semua tersedia untuk memudahkan Anda.',

    'slogan1' => 'SAATNYA MERANCANG PETUALANGAN ANDA SELANJUTNYA',
    'slogan2' => "Ke mana pun tujuan Anda, biarkan kami yang mengurus semuanya. Mulai dari tiket, akomodasi, hingga jadwal perjalanan yang sempurna, Anda hanya perlu menikmati setiap momennya.",

    'paketdomestik' => 'PAKET PERJALANAN DOMESTIK',

    'paketinternasional' => 'PAKET PERJALANAN INTERNASIONAL',

    'domestik1' => 'Domestik 1',
    'domestik2' => 'Domestik 2',
    'domestik3' => 'Domestik 3',
    'domestik4' => 'Domestik 4',

    'musimsalju1' => 'Seri Musim Salju 1',
    'musimsalju2' => 'Seri Musim Salju 2',
    'vietnam1' => 'Seri Vietnam 1',
    'vietnam2' => 'Seri Vietnam 2',

    'deskrip' => 'The Sun Tour en Travel adalah biro perjalanan profesional di Semarang yang berpengalaman sejak 2012. Kami siap melayani kebutuhan wisata, studi tur, MICE, dan transportasi untuk destinasi domestik maupun internasional.',

    'bahasa' => 'Pilih Bahasa',
    'jalan' => 'Jl. Jangli Tlawah V No.39a, Jatingaleh, Kec. Candisari, Kota Semarang, Central Java 50255.',
];
