<?php

return [
    'description' => '<h1 class="fade text-xl md:text-2xl mt-2 leading-snug" style="font-family: \'ZCOOL XiaoWei\', cursive;">
    The SUN Tour en Travel is a Tour Planner, Tour Operator, and Tour Agency located in SEMARANG, Central Java.
    Established in 2012, we have an expert team ready to accommodate all travel needs including Tours,
    Comparative Studies, Golf, and MICE, as well as providing domestic and international transportation services.
    Entrust all your travel needs only to our professional team, The SUN Tour en Travel Semarang.
</h1>'

];