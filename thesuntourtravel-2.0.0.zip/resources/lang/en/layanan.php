<?php

return [
    'button' => [
        'mobil' => 'Car Rental',
        'kapal' => 'Yacht Rental',
        'mice' => 'MICE Services',
        'ziarah' => 'Pilgrimage',
    ],
    'layananunggulan' => 'Our Services',
    'deskripsi' => '"Explore our wide range of services designed to meet your travel, business, and spiritual experience needs. From comfortable transportation to memorable moments in conferences and pilgrimage journeys, each category holds something special that will make your journey more meaningful."',
    'deskripsi2' => 'Click the Button on the Top Left for Service Information.',
    'mobilinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Car Rental</h1>
    <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Enjoy the freedom
        to explore easily and comfortably.
        Our car rental service is ready to accompany your journey, whether for business matters or a family
        vacation."</p>
    <ul class="list-disc ml-6 text-xl">
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Offering a variety of vehicle options to suit your needs.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Flexible for short or long trips.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Providing full comfort and privacy during your journey.</li>
    </ul>
    <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">For More
        Information, Contact Us.</h1>',
    'kapalinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Yacht Rental</h1>
        <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">
            "Feel a different kind of sensation by sailing across the sea or along the river.
            Our yacht rental service offers an exclusive and unforgettable experience."
        </p>
        <ul class="list-disc ml-6 text-xl">
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Perfect for tours, special events, or private trips.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Equipped with safe and modern facilities.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Offering both adventure and relaxation.</li>
        </ul>
        <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">
            For More Information, Contact Us.
        </h1>',
    'miceinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">MICE Services</h1>
        <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Bring your professional events to life with our integrated MICE services.
            From small meetings to large conferences, we are ready to support the success of your event."</p>
        <ul class="list-disc ml-6 text-xl">
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Providing complete venues and facilities for events of all scales.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Supporting logistical, technical, and hospitality needs.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Delivering a memorable experience for participants and guests.</li>
        </ul>
        <h1 class=" mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">For More
            Information, Contact Us.</h1>',
    'ziarahinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Pilgrimage Service</h1>
        <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Find inner peace
            and a deep spiritual experience through our pilgrimage travel services."</p>
        <ul class="list-disc ml-6 text-xl">
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Designed for comfort and solemnity during worship travel.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Featuring meaningful routes and destinations.</li>
            <li style="font-family: \'ZCOOL XiaoWei\', serif;">Offering guidance to ensure a well-organized and peaceful journey.</li>
        </ul>
        <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">For More
            Information, Contact Us.</h1>',


];