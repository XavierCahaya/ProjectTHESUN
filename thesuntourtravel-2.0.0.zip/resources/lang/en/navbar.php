<?php

return [
    'home' => 'Home',
    'packages' => 'Packages',
    'about' => 'About Us',
];
