<?php

return [
    'negoro' => '<div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'jawatengah\')">Central Java</div>
                    <div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'korea\')">Korean</div>
                    <div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'india\')">India</div>
                    <div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'vietnam\')">Vietnam</div>
                    <div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'jepang\')">Japan</div>
                    <div class="swiper-slide category-box" style="font-family: \'Roboto\', sans-serif;"
                        onclick="showCategory(\'china\')">China</div>',
    'jatengg' => '<h1 class="text-4xl text-shadow-lg/50 font-bold mb-6 text-center block md:hidden"
                    style="font-family: \'Vast Shadow\', cursive;">
                    C E N T R A L
                </h1>
                <h1 class="text-4xl text-shadow-lg/50 font-bold mb-6 text-center block md:hidden"
                    style="font-family: \'Vast Shadow\', cursive;">
                    J A V A
                </h1>
                  <h1 class="text-7xl text-shadow-lg/50 font-bold mb-6 text-center hidden md:block"
                    style="font-family: \'Vast Shadow\', cursive;">
                    C E N T R A L
                </h1>
                <h1 class="text-7xl text-shadow-lg/50 font-bold mb-6 text-center hidden md:block"
                    style="font-family: \'Vast Shadow\', cursive;">
                    J A V A
                </h1>',
    'jelajahpaket' => 'EXPLORE OUR TOUR PACKAGES HERE',
    'geser' => 'Swipe Right or Left to View Another Categories',
    'deskripmalay' => 'Malaysian durian = god-level creaminess!',
    'deskripmalay2' => 'Thick flesh, naturally sweet, and a strong aroma that’s insanely addictive. Try a fresh one just once… and your diet is instantly forgotten. 🤣✨',
    'deskripsinga' => 'Only in Singapore: a dedicated bicycle elevator!',
    'deskripsinga2' => 'Neat, well-designed, and super thoughtful. Small things like this are what make the city feel so smart and effortless.',
    'paketsemarang' => 'Packages Golf : Semarang',
    'paketdieng' => 'Dieng Package 4 Days 3 Nights',
    'dienginfo' => '
        <li style="font-family: \'Roboto\', sans-serif;">1. 5 Dieng Tourist Spots</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. Private Transport</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Mineral Water, Meals, Toll Fees</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Telaga Menjer Boat Ride</li>
    ',
    'paketkarimunjawa' => 'Karimunjawa Package 3 Days 2 Night',
    'karimunjawainfo' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. Visit 3 Islands</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. Homestay, Hotel, Cottage</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Breakfast, Lunch, Dinner Included</li>
    </ul>
    ',
    'paketmagelang' => 'Magelang Package',
    'magelanginfo' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. Nepal Van Java</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. Chicken Church</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Svargabumi</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. VW Touring</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Borobudur Temple</li>
    </ul>
    ',
    'paketmagelang2' => 'Magelang Package: Buddhist Pilgrimage',
    'magelanginfo2' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. Mendut Temple</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. Pawon Temple</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Borobudur Temple</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Pradaksina, Fang Sheng, Blessing</li>
    </ul>
    ',
    'paketsolo' => 'Solo Package 4 Days 3 Nights',
    'soloinfo' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 6 Solo Tourist Spots</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 3-Star Hotel</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Breakfast Included</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Local Transportation</li>
    </ul>
    ',
    'korea' => 'K O R E A N',
    'paketkorea' => 'Korea Package 6 Days',
    'koreainfo' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. Travel Bus</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. Hotel (Twin Bed/Triple Bed)</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Tour Guide</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Travel Equipment</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Travel Insurance</li>
    </ul>
    ',
    'paketvietnam' => 'Packages Vietnam',
    'vietnam1' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 5 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 4 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. 3-Star Hotel (Twin/Triple)</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Travel Equipment</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Travel Insurance</li>
    </ul>',
    'vietnam2' => '
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 6 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 4 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. 3-Star Hotel (Twin/Triple)</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Travel Equipment</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Travel Insurance</li>
    </ul>
    ',
    'paketqutub' => 'Places of Interest in India: Qutub Minar',
    'paketgate' => 'Places of Interest in India: India Gate',
    'jepang' => 'J A P A N',
    'jepanginfo1' => '<h5 style="font-family: \'Roboto\', sans-serif;"
        class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Winter Series: Kawazu Sakura
    </h5>
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 6 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 4 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Hotel & Breakfast</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Public Transportation</li>
    </ul>',
    'jepanginfo2' => '<h5 style="font-family: \'Roboto\', sans-serif;"
    class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Winter Series: Tokyo
    Southern
    Hokkaido
    </h5>
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 7 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 5 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Hotel & Breakfast</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Public Transportation</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Snowmobile</li>
    </ul>'
    ,
    'jepanginfo3' => '<h5 style="font-family: \'Roboto\', sans-serif;"
    class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Winter Series: Golden
    Route
    Hokkaido
    </h5>
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 8 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 6 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Hotel & Breakfast</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Public Transportation</li>
    </ul>'
    ,
    'jepanginfo4' => '<h5 style="font-family: \'Roboto\', sans-serif;"
    class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Winter Series: Gala
    Yuzawa Ski
    Hokkaido
    </h5>
    <ul class="ml-5 mb-6 text-body">
        <li style="font-family: \'Roboto\', sans-serif;">1. 7 Days</li>
        <li style="font-family: \'Roboto\', sans-serif;">2. 3 Tourist Destinations</li>
        <li style="font-family: \'Roboto\', sans-serif;">3. Hotel & Breakfast</li>
        <li style="font-family: \'Roboto\', sans-serif;">4. Public Transportation</li>
        <li style="font-family: \'Roboto\', sans-serif;">5. Snow Mobile</li>
    </ul>'
    ,
    'pakethawa' => 'Places of Interest in India: Hawa Mahal',
    'paketcity' => 'Places of Interest in India : CITY PALACE',
];
