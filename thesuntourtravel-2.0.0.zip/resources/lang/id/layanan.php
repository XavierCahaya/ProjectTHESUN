<?php

return [
    'button' => [
        'mobil' => 'Mobil',
        'kapal' => 'Kapal Pesiar',
        'mice' => 'MICE',
        'ziarah' => 'Ziarah',
    ],
    'layananunggulan' => 'Layanan Kami ',
    'deskripsi' => '"Jelajahi berbagai pilihan layanan kami
                yang dirancang untuk memenuhi kebutuhan perjalanan, bisnis, dan pengalaman spiritual Anda.
                Dari kenyamanan transportasi hingga momen berkesan dalam konferensi dan ziarah,
                setiap kategori menyimpan kejutan yang akan membuat perjalanan Anda lebih bermakna."',
    'deskripsi2' => 'Klik Tombol Di Kiri
                Atas Untuk Informasi Layanan.',
    'mobilinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Sewa Mobil</h1>
    <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Nikmati kebebasan
        menjelajah dengan mudah dan nyaman.
        Layanan rental mobil kami siap menemani perjalanan Anda, baik untuk urusan bisnis maupun liburan

        keluarga."</p>
    <ul class="list-disc ml-6 text-xl">
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Menawarkan berbagai pilihan kendaraan sesuai kebutuhan.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Fleksibel untuk perjalanan singkat maupun jangka panjang.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Memberikan kenyamanan dan privasi penuh selama perjalanan.</li>
    </ul>
    <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">Informasi Lebih
        Lanjut, Hubungi Kami.</h1>',

    'kapalinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Sewa Kapal Pesiar</h1>
    <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">
        "Rasakan sensasi berbeda dengan berlayar di laut atau menyusuri sungai.
        Rental kapal kami menghadirkan pengalaman eksklusif yang tak terlupakan."
    </p>
    <ul class="list-disc ml-6 text-xl">
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Cocok untuk wisata, acara khusus, atau perjalanan pribadi.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Menyediakan kapal dengan fasilitas modern dan aman.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Memberikan nuansa petualangan sekaligus relaksasi.</li>
    </ul>
    <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">
        Informasi Lebih Lanjut, Hubungi Kami.
    </h1>',

    'miceinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Layanan MICE</h1>
    <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Wujudkan acara profesional
        Anda dengan layanan MICE yang terintegrasi.
        Dari rapat kecil hingga konferensi besar, kami siap mendukung kesuksesan acara Anda."</p>
    <ul class="list-disc ml-6 text-xl">
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Menyediakan ruang dan fasilitas lengkap untuk berbagai
            skala acara.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Mendukung kebutuhan logistik, teknis, dan hospitality.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Memberikan pengalaman berkesan bagi peserta dan tamu.</li>
    </ul>
    <h1 class=" mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">Informasi Lebih
        Lanjut, Hubungi Kami.</h1>',
    'ziarahinfo' => '<h1 class="text-3xl mb-4 text-center" style="font-family: \'Vast Shadow\', cursive;">Layanan Ziarah</h1>
    <p class="mb-4 text-2xl text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">"Temukan ketenangan batin
        dan pengalaman spiritual yang mendalam melalui layanan
        perjalanan ziarah kami."</p>
    <ul class="list-disc ml-6 text-xl">
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Dirancang untuk kenyamanan dan kekhusyukan perjalanan
            ibadah.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Menghadirkan rute dan destinasi yang penuh makna.</li>
        <li style="font-family: \'ZCOOL XiaoWei\', serif;">Memberikan pendampingan agar perjalanan lebih teratur dan
            tenang.</li>
    </ul>
    <h1 class="mt-20 text-xl mb-4 text-center" style="font-family: \'ZCOOL XiaoWei\', serif;">Informasi Lebih
        Lanjut, Hubungi Kami.</h1>',

];