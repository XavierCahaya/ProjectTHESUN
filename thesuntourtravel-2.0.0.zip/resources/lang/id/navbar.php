<?php

return [
    'home' => 'Beranda',
    'packages' => 'Paket',
    'about' => 'Tentang Kami',
];
