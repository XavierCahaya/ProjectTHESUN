{{-- <div class="w-450 p-9 text-center border-b-4 border-amber-400">
                <h1 class="relative text-center text-black text-5xl" style="font-family: 'ZCOOL XiaoWei', serif;">Visi &
                    Misi</h1>

                <div class="mt-5 flex justify-center gap-10">
                    <div class="bg-white h-auto w-700 p-5 text-center border border-gray-300 shadow-lg rounded-lg">
                        <h1 class="text-3xl mt-3" style="font-family: 'Abhaya Libre', serif; font-weight:600;">Visi</h1>
                        <p class="text-xl mt-2 leading-snug" style="font-family: 'Abhaya Libre', serif;">
                            Dengan lebih dari satu dekade pengalaman, kami memahami cara merancang perjalanan
                            yang berkesan dan tanpa hambatan untuk Anda.
                        </p>
                    </div>

                    <div class="bg-white h-auto w-700 p-5 text-center border border-gray-300 shadow-lg rounded-lg">
                        <h1 class="text-3xl mt-3" style="font-family: 'Abhaya Libre', serif; font-weight:600;">
                            Misi
                        </h1>
                        <p class="text-xl mt-2 leading-snug" style="font-family: 'Abhaya Libre', serif;">
                            Mulai dari tiket, akomodasi, transportasi, hingga paket wisata kustom, MICE,
                            dan studi tur, semua tersedia untuk memudahkan Anda.
                        </p>
                    </div>
                </div>

            </div> --}}