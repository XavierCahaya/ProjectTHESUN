<nav class="bg-white p-2 shadow-xl sticky top-0 z-50">
    <div class="flex justify-between items-center">
        <div class="w-40">
            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('image/logo.png')); ?>" class="h-16 ml-20" />
            </a>
        </div>

        <button id="menu-btn" class="md:hidden text-black focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24"
                stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>

        <ul class="hidden md:flex border-b-2 border-amber-400 mr-7 p-3 flex-row font-medium space-x-8 text-lg"
            style="font-family: 'Roboto', sans-serif;">
            <li><a href="<?php echo e(route('home')); ?>"
                    class=" text-amber-400 hover:text-amber-600 transition"><?php echo e(__('navbar.home')); ?></a>
            </li>
            <li><a href="<?php echo e(route('packages')); ?>"
                    class=" text-amber-400 hover:text-amber-600 transition"><?php echo e(__('navbar.packages')); ?></a>
            </li>
            <li><a href="<?php echo e(route('about')); ?>"
                    class=" text-amber-400 hover:text-amber-600 transition"><?php echo e(__('navbar.about')); ?></a>
            </li>
        </ul>

        <div class="hidden md:flex flex-row items-center space-x-4 mr-20">  
            <!-- Language Switcher -->
            <div class="relative">
                <button id="lang-btn"
                    class="px-3 py-1 border border-amber-400 rounded-lg text-sm hover:bg-gray-100 transition">
                    <?php echo e(strtoupper(app()->getLocale())); ?>

                </button>

                <div id="lang-menu" class="hidden absolute right-0 mt-2 bg-white border rounded-lg shadow-lg w-24">
                    <a href="<?php echo e(route('set.locale', 'id')); ?>" class="block px-3 py-2 text-black text-sm hover:bg-amber-400">🇮🇩
                        Indonesia</a>
                    <a href="<?php echo e(route('set.locale', 'en')); ?>" class="block px-3 py-2 text-black text-sm hover:bg-amber-400">🇺🇸
                        English</a>
                </div>
            </div>
        </div>
    </div>

    <div id="mobile-menu" class="hidden md:hidden mt-4 rounded-lg p-4 space-y-2">
        <a href="<?php echo e(route('home')); ?>" class="text-shadow-lg/10 text-amber-500 hover:text-amber-600 transition"><?php echo e(__('navbar.home')); ?></a>
        <hr class="w-full h-[2px] bg-white shadow-lg shadow-black ">
        <a href="<?php echo e(route('packages')); ?>" class="text-shadow-lg/10 text-amber-500 hover:text-amber-600 transition"><?php echo e(__('navbar.packages')); ?></a>
        <hr class="w-full h-[2px] bg-white shadow-lg shadow-black ">
        <a href="<?php echo e(route('about')); ?>" class="text-shadow-lg/10 text-amber-500 hover:text-amber-600 transition"><?php echo e(__('navbar.about')); ?></a>
        <hr class="w-full h-[2px] bg-white shadow-lg shadow-black ">
    </div>
</nav>

<script>
    document.getElementById('lang-btn').addEventListener('click', function() {
        const menu = document.getElementById('lang-menu');
        menu.classList.toggle('hidden');
    });

    const menuBtn = document.getElementById('menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    menuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
</script>
<?php /**PATH D:\thesuntourtravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>