

<?php $__env->startSection('container'); ?>
    <br>
    <br>

    <style>
        .category-box {
            padding: 10px 20px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            background: white;
            transition: 0.2s;
            width: auto !important;
            margin-right: 10px !important;
        }

        .category-box:hover {
            background-color: #fbbf24;
            color: white;
            border-color: #fbbf24;
        }

        .swiper-slide {
            width: auto !important;
        }
    </style>

    <div class="h-20 flex justify-center relative overflow-hidden p-2">
        <h1 class="relative z-10 text-center text-black text-4xl" style="font-family: 'Vast Shadow', cursive;">
            JELAJAHI PAKET TOUR DAN TRAVEL KAMI DISINI
        </h1>
    </div>

    <div class="w-full flex justify-center">
        <div class="overflow-hidden rounded-xl border border-gray-300 px-6 py-3 max-w-[800px] w-full">

            <div class="swiper categorySwiper">
                <div class="swiper-wrapper text-lg font-medium cursor-pointer select-none">

                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('semarang')">Semarang</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('solo')">Solo</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('dieng')">Dieng</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('karimunjawa')">Karimunjawa</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('magelang')">Magelang</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('korea')">Korea</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('vietnam')">Vietnam</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('jepang')">Jepang</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('malaysia')">Malaysia</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('singapore')">Singapore</div>

                </div>
            </div>

        </div>
    </div>

    <h1 class="mt-2 text-sm flex justify-center items-center text-center">Geser Ke Kanan atau Ke Kiri Untuk Melihat Kategori
        Yang Lain</h1>

    <br>

    <hr class="h-3 bg-amber-400">

    
    <div id="semarang" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/semarang.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center" style="font-family: 'Vast Shadow', cursive;">
                    S E M A R A N G
                </h1>

                <div
                    class="flex flex-col md:flex-row items-center md:items-start text-black rounded-lg shadow-md p-4 w-250">

                    <div class="flex-shrink-0">
                        <img src="image/semarang.jpg" alt="" class="w-80 h-80 object-cover rounded-lg">
                    </div>

                    <div class="md:ml-4 mt-4 md:mt-0 text-left">
                        <h1 class="text-4xl text-shadow-lg/50 font-bold text-white mt-20 mb-2" style="font-family: 'Roboto', sans-serif;">
                            ARTIKEL SEMARANG
                        </h1>
                        <p class="text-xl text-shadow-lg/50 text-white leading-relaxed" style="font-family: 'Roboto', sans-serif;">
                            ISI ARTIKEL
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        src="image/brosursemarang.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET GOLF</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        src="image/brosursemarang.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET GOLF</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    <div id="malaysia" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/malaysia.webp" alt="Malaysia" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center" style="font-family: 'Vast Shadow', cursive;">
                    M A L A Y S I A
                </h1>

                <div
                    class="flex flex-col md:flex-row items-center md:items-start text-black rounded-lg shadow-md p-4 w-250">

                    <div class="flex-shrink-0">
                        <img src="image/artikelmalaysia.jpeg" alt="Durian Malaysia"
                            class="w-80 h-80 object-cover rounded-lg">
                    </div>

                    <div class="md:ml-4 mt-4 md:mt-0 text-left">
                        <h1 class="text-4xl text-shadow-lg/50 font-bold text-white mt-20 mb-2"
                            style="font-family: 'Roboto', sans-serif;">
                            Durian Malaysia = creamy level dewa!
                        </h1>
                        <p class="text-2xl text-shadow-lg/50 font-bold text-white leading-relaxed"
                            style="font-family: 'Roboto', sans-serif;">
                            Daging tebal, manis legit, aroma kuat tapi bikin nagih.
                            Sekali coba yang fresh… auto lupa diet. 🤣✨
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0" src="image/.jpeg"
                        alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET MALAYSIA</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        src="image/.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET MALAYSIA</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    <div id="singapore" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/singapore.jpg" alt="Singapore" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center" style="font-family: 'Vast Shadow', cursive;">
                    S I N G A P O R E
                </h1>

                <div
                    class="flex flex-col md:flex-row items-center md:items-start text-black rounded-lg shadow-md p-4 w-250">

                    <div class="flex-shrink-0">
                        <img src="image/artikelsingapore.jpeg" alt="" class="w-80 h-80 object-cover rounded-lg">
                    </div>

                    <div class="md:ml-4 mt-4 md:mt-0 text-left">
                        <h1 class="text-4xl text-shadow-lg/50 font-bold text-white mt-20 mb-2"
                            style="font-family: 'Roboto', sans-serif;">
                            Cuma di Singapura: lift khusus sepeda!
                        </h1>
                        <p class="text-2xl text-shadow-lg/50 font-bold text-white leading-relaxed"
                            style="font-family: 'Roboto', sans-serif;">
                            Rapi, teratur, dan super thoughtful.
                            Hal kecil yang bikin kota ini selalu terasa smart & effortless.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        src="image/.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET SINGAPORE</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        src="image/.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">PAKET SINGAPORE</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>





    <script>
        var swiper = new Swiper(".categorySwiper", {
            slidesPerView: "auto",
            spaceBetween: 10,
            freeMode: true,
        });

        function showCategory(category) {
            // Sembunyikan semua konten kategori
            document.querySelectorAll('.category-content')
                .forEach(el => el.classList.add('hidden'));

            // Tampilkan kategori sesuai yang diklik
            document.getElementById(category).classList.remove('hidden');
        }

        // 👉 Tambahkan ini agar default-nya Semarang tampil
        document.addEventListener("DOMContentLoaded", function() {
            showCategory('semarang');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\thesuntourtravel\resources\views/packets.blade.php ENDPATH**/ ?>