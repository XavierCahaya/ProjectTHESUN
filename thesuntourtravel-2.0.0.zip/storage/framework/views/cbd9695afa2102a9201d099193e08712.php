

<?php $__env->startSection('container'); ?>
    <br>
    <br>

    <style>
        .category-box {
            padding: 10px 20px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            background: white;
            transition: 0.2s;
            width: auto !important;
            margin-right: 10px !important;
        }

        .category-box:hover {
            background-color: #fbbf24;
            color: white;
            border-color: #fbbf24;
        }

        .swiper-slide {
            width: auto !important;
        }

        /* animasi load fade */
        .fade {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 1s ease, transform 1s ease;
        }

        .fade.show {
            opacity: 1;
            transform: translateY(0);
        }

        /* ==== Fade dari kiri ==== */
        .fade-left {
            opacity: 0;
            transform: translateX(-30px);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }

        .fade-left.show {
            opacity: 1;
            transform: translateX(0);
        }

        /* ==== Fade dari kanan ==== */
        .fade-right {
            opacity: 0;
            transform: translateX(30px);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }

        .fade-right.show {
            opacity: 1;
            transform: translateX(0);
        }

        /* ==== Zoom In ==== */
        .zoom-in {
            opacity: 0;
            transform: scale(0.9);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }

        .zoom-in.show {
            opacity: 1;
            transform: scale(1);
        }

        /* ==== Zoom Out ==== */
        .zoom-out {
            opacity: 0;
            transform: scale(1.1);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }

        .zoom-out.show {
            opacity: 1;
            transform: scale(1);
        }
    </style>

    <div class="h-20 flex justify-center relative overflow-hidden p-2">
        <h1 class="relative z-10 text-center text-black text-4xl" style="font-family: 'Vast Shadow', cursive;">
            <?php echo e(__('packages.jelajahpaket')); ?>

        </h1>
    </div>

    <div class="w-full flex justify-center">
        <div class="overflow-hidden rounded-xl border border-gray-300 px-6 py-3 max-w-[800px] w-full">

            <div class="swiper categorySwiper">
                <div class="swiper-wrapper text-lg font-medium cursor-pointer select-none">

                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('jawatengah')">Jawa Tengah</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('korea')">Korea</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('india')">India</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('vietnam')">Vietnam</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('jepang')">Jepang</div>
                    <div class="swiper-slide category-box" style="font-family: 'Roboto', sans-serif;"
                        onclick="showCategory('china')">China</div>
                    

                </div>
            </div>

        </div>
    </div>

    <h1 class="mt-2 text-sm flex justify-center items-center text-center"><?php echo e(__('packages.geser')); ?></h1>

    <br>

    <div id="imgPopup" class="fixed inset-0 bg-black/70 hidden z-50 flex items-center justify-center">
        <div class="relative">
            <button onclick="closePopup()"
                class="absolute -top-4 -right-4 bg-white text-black rounded-full 
                w-15 h-15 flex items-center justify-center shadow-lg text-3xl">
                ×
            </button>
            <img id="popupImage" class="max-w-[90vw] max-h-[90vh] rounded shadow-lg">
        </div>
    </div>


    
    <div id="jawatengah" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/semarang.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    J A W A - T E N G A H
                </h1>

                
            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosursemarang.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketsemarang')); ?></h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurdieng.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading"
                            style="font-family: 'Roboto', sans-serif;"><?php echo e(__('packages.paketdieng')); ?></h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 5 Lokasi Wisata Dieng</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Private Transport</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Air mineral, Makan, Biaya Tol</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Perahu telaga menjer</li>
                        </ul>
                    </div>
                </div>

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurkarimun.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading"
                            style="font-family: 'Roboto', sans-serif;"><?php echo e(__('packages.paketkarimunjawa')); ?></h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. Kunjungan 3 pulau</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Homestay, Hotel, Cottage</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Makan Pagi, Makan Siang, Makan Malam</li>
                        </ul>
                    </div>
                </div>

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)"src="image/brosurmagelang.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketmagelang')); ?></h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. Nepal Van Java</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Gereja Ayam</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Svargabumi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. VW Touring</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Candi Borobudur</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurmagelang2.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketmagelang2')); ?>

                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. Candi Mendut</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Candi Pawon</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Candi Borobudur</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Pradhaksina, Fang Sheng, Blessing </li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosursolo.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading"><?php echo e(__('packages.paketsolo')); ?>

                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 6 Lokasi Wisata Solo</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Hotel Bintang 3</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Makan Pagi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Transportasi Lokal</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    <div id="korea" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/korea.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    K O R E A
                </h1>

                

            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurkorea.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading"
                            style="font-family: 'Roboto', sans-serif;"><?php echo e(__('packages.paketkorea')); ?></h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. Bis perjalanan</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. Hotel (Twin Bed/Triple Bed)</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Pemandu Tur</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Perlengkapan perjalanan</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Asuransi perjalanan</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>

    
    <div id="india" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/india.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    I N D I A
                </h1>

                

            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurindia.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketqutub')); ?></h5>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurindia2.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketgate')); ?></h5>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurindia3.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.pakethawa')); ?></h5>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurindia4.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">
                            <?php echo e(__('packages.paketcity')); ?></h5>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    <div id="vietnam" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/vietnam2.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    V I E T N A M
                </h1>

                

            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurvietnam3.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Paket Vietnam</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 5 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 4 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel Bintang 3 (Twin/Triple)</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Perlengkapan Perjalanan</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Asuransi Perjalanan</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurvietnam2.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Paket Vietnam</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 6 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 4 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel Bintang 3 (Twin/Triple)</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Perlengkapan Perjalanan</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Asuransi Perjalanan</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    <div id="jepang" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/jepang.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    J E P A N G
                </h1>

                

            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurjepang.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Seri Musim Dingin : Kawazu
                            Sakura
                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 6 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 4 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel & Makan Pagi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Transportasi Publik</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurjepang2.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Seri Musim Dingin : Tokyo
                            Southern
                            Hokkaido
                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 7 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 5 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel & Makan Pagi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Transportasi Publik</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Snow Mobile</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurjepang3.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Seri Musim Dingin : Golden
                            Route
                            Hokkaido
                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 8 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 6 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel & Makan Pagi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Transportasi Publik</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurjepang4.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 style="font-family: 'Roboto', sans-serif;"
                            class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Seri Musim Dingin : Gala
                            Yuzawa Ski
                            Hokkaido
                        </h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li style="font-family: 'Roboto', sans-serif;">1. 7 Hari</li>
                            <li style="font-family: 'Roboto', sans-serif;">2. 3 Destinasi Wisata</li>
                            <li style="font-family: 'Roboto', sans-serif;">3. Hotel & Makan Pagi</li>
                            <li style="font-family: 'Roboto', sans-serif;">4. Transportasi Publik</li>
                            <li style="font-family: 'Roboto', sans-serif;">5. Snow Mobile</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>



    
    <div id="china" class="category-content hidden">

        <div class="relative w-[1901px] h-[800px] overflow-hidden shadow-md mb-10">

            <img src="image/china.jpg" alt="" class="absolute inset-0 w-full h-full object-cover">

            <div class="absolute inset-0 bg-black/30"></div>

            <div class="relative z-10 flex flex-col items-center justify-center h-full p-6 text-white">

                <h1 class="text-5xl text-shadow-lg/50 font-bold mb-6 text-center"
                    style="font-family: 'Vast Shadow', cursive;">
                    C H I N A
                </h1>

                

            </div>
        </div>
        
        <div class="flex justify-center p-10">
            <div class="grid grid-cols-2 gap-15">

                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurchina.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Paket China</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurchina2.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Paket China</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>
                <div
                    class="fade flex flex-col items-center rounded-xl p-6 rounded-base shadow-xs md:flex-row w-[800px] border-b-4 border-amber-400">
                    <img class="rounded-lg object-cover w-full rounded-base h-80 md:h-auto md:w-[400px] mb-4 md:mb-0"
                        onclick="openPopup(this.src)" src="image/brosurchina3.jpeg" alt="">
                    <div class="flex flex-col justify-between md:p-4 leading-normal">
                        <h5 class="ml-5 mb-2 text-2xl font-bold tracking-tight text-heading">Paket China</h5>
                        <ul class="ml-5 mb-6 text-body">
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                            <li>TESSSSSSSSSSSSSS</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </div>


    
    
    
    


    
    
    
    

    <script>
        var swiper = new Swiper(".categorySwiper", {
            slidesPerView: "auto",
            spaceBetween: 10,
            freeMode: true,
        });

        function showCategory(category) {
            // Sembunyikan semua konten kategori
            document.querySelectorAll('.category-content')
                .forEach(el => el.classList.add('hidden'));

            // Tampilkan kategori sesuai yang diklik
            document.getElementById(category).classList.remove('hidden');
        }

        // Tambahkan ini agar default-nya Semarang tampil
        document.addEventListener("DOMContentLoaded", function() {
            showCategory('jawatengah');
        });

        function openPopup(src) {
            document.getElementById("popupImage").src = src;
            document.getElementById("imgPopup").classList.remove("hidden");
        }

        function closePopup() {
            document.getElementById("imgPopup").classList.add("hidden");
        }

        // fungsi load fade
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("show");
                }
            });
        });
        document.querySelectorAll(".fade, .fade-left, .fade-right, .zoom-in, .zoom-out").forEach(el => observer.observe(el));
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\thesuntourtravel\resources\views/packages.blade.php ENDPATH**/ ?>